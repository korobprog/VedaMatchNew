---
name: responses-image-generation
description: Use when generating or editing images through the OpenAI Responses API image_generation tool, including image inputs, masks, Codex auth/config discovery, or no-SDK standard-library API calls.
---

# Responses Image Generation

Use this skill to generate or edit images through `/responses` with the hosted `image_generation` tool. The reusable script is in `scripts/responses_image.py`.

## When to Use

- Generate an image through the Responses API hosted `image_generation` tool.
- Edit an existing image through Responses API.
- Edit with a mask through Responses API.
- Use image inputs from local files, base64 data URLs, or OpenAI file IDs.
- Use `~/.codex/auth.json` for `OPENAI_API_KEY`.
- Use `~/.codex/config.toml` for `base_url` or `model`.
- Avoid installing the `openai` SDK.

Use the Images API only when the user explicitly asks for `/images/generations` or `/images/edits`.

## Rules

- Never print API keys, bearer tokens, or raw secret files.
- Prefer `OPENAI_API_KEY`, `OPENAI_BASE_URL`, and `OPENAI_MODEL` from the environment.
- If missing, the script reads `~/.codex/auth.json` field `OPENAI_API_KEY`.
- If missing, the script reads `~/.codex/config.toml` fields `base_url` and `model`.
- Use a text-capable Responses model such as `gpt-5.5`, `gpt-5`, or the configured model. Do not put `gpt-image-*` in the Responses `model` field.
- Put image-generation options on the `image_generation` tool object.
- For edits, include at least one image in the user message as `input_image`.
- For normal edits without a mask, local images are sent as base64 data URLs and do not require the Files API.
- For mask edits, the original image and mask must be uploaded through the Files API with `purpose=vision`; set `input_image_mask: {"file_id": mask_file_id}` on the tool. The mask applies to the first input image.
- Mask and edited image must be the same format and size, under 50MB, and the mask must contain an alpha channel.
- Masking is prompt-guided; do not promise pixel-perfect boundaries.
- Save outputs relative to the current working directory.

## Inputs

Set environment variables before running `scripts/responses_image.py`:

| User asks for | Environment input | Default |
| --- | --- | --- |
| prompt | `IMAGE_PROMPT` | required |
| output path | `IMAGE_OUTPUT` | `output/imagegen/generated-image.png` |
| action | `IMAGE_ACTION` | `generate` if no image, otherwise `edit` |
| input image paths | `IMAGE_INPUTS` | none |
| existing OpenAI file IDs | `IMAGE_FILE_IDS` | none |
| input image data URLs | `IMAGE_DATA_URLS` | none |
| mask path | `IMAGE_MASK` | none |
| size | `IMAGE_SIZE` | unset |
| quality | `IMAGE_QUALITY` | unset |
| output format | `IMAGE_FORMAT` | `png` |
| compression | `IMAGE_COMPRESSION` | unset |
| background | `IMAGE_BACKGROUND` | unset |
| mainline model | `IMAGE_MODEL` or `OPENAI_MODEL` | config `model`, then `gpt-5.5` |

`IMAGE_INPUTS` accepts paths separated by `:` on Unix or by `;` on Windows. `IMAGE_FILE_IDS` and `IMAGE_DATA_URLS` accept comma-separated values. For mask edits, prefer one primary image path or file ID.

## Workflow

1. Locate the skill directory and run `scripts/responses_image.py` from the current project.
2. Set `IMAGE_PROMPT` from the user's actual request.
3. For edits, set `IMAGE_INPUTS`, `IMAGE_FILE_IDS`, or `IMAGE_DATA_URLS`.
4. For mask edits, set `IMAGE_MASK`.
5. Run the script. If sandbox/network blocks the call, request network permission and rerun the same command.
6. Show the generated output with `view_image`.
7. Report the relative output path.

## Examples

Generate:

```bash
IMAGE_PROMPT='Draw a cozy late-night software studio, cinematic lighting, no readable text' \
IMAGE_OUTPUT='output/imagegen/studio.png' \
IMAGE_QUALITY='medium' \
IMAGE_SIZE='1536x1024' \
python3 ~/.agents/skills/responses-image-generation/scripts/responses_image.py
```

Edit without mask:

```bash
IMAGE_PROMPT='Edit this image into a bright morning version while preserving the desk and camera angle' \
IMAGE_INPUTS='output/imagegen/studio.png' \
IMAGE_OUTPUT='output/imagegen/studio-morning.png' \
IMAGE_ACTION='edit' \
python3 ~/.agents/skills/responses-image-generation/scripts/responses_image.py
```

Edit with mask:

```bash
IMAGE_PROMPT='Edit only the masked area: replace it with a brass desk lamp; preserve everything else' \
IMAGE_INPUTS='input/desk.png' \
IMAGE_MASK='input/mask.png' \
IMAGE_OUTPUT='output/imagegen/desk-masked-edit.png' \
IMAGE_ACTION='edit' \
IMAGE_QUALITY='high' \
python3 ~/.agents/skills/responses-image-generation/scripts/responses_image.py
```

## Failure Handling

- `OPENAI_API_KEY not found`: ask the user to provide `OPENAI_API_KEY` or a normal Codex `auth.json`.
- `HTTP 404` on `/responses`: the provider may not support Responses API at that base URL.
- `Unknown parameter`: remove provider-unsupported optional tool fields and retry with the smallest payload: `type`, `action`, `output_format`, and `input_image_mask` only when needed.
- `IMAGE_ACTION=edit requires IMAGE_INPUTS, IMAGE_FILE_IDS, or IMAGE_DATA_URLS`: ask for an input image or switch to generation.
- `File upload HTTP 404`: the configured provider does not expose the Files API; unmasked edits can still use data URLs, but Responses mask edits require file IDs on a provider that supports `/files`.
- Mask errors: verify same dimensions/format, under 50MB, and alpha channel on the mask.
- `background: "transparent"` with `gpt-image-2`: unsupported; use `auto`/opaque or another supported path.

## Final Response

When successful, answer in the user's language with the relative output path.
