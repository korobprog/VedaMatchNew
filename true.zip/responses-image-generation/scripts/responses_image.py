import base64
import json
import mimetypes
import os
import re
import sys
import uuid
import urllib.error
import urllib.request
from pathlib import Path


DEFAULT_OUTPUT_PATH = "output/imagegen/generated-image.png"
DEFAULT_BASE_URL = "https://api.openai.com/v1"
DEFAULT_MODEL = "gpt-5.5"


def read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}


def read_text(path):
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return ""


def find_toml_string(text, key):
    match = re.search(rf"^{re.escape(key)}\s*=\s*\"([^\"]+)\"", text, re.MULTILINE)
    return match.group(1) if match else None


def split_paths(value):
    if not value:
        return []
    sep = ";" if os.name == "nt" else os.pathsep
    return [Path(part).expanduser() for part in value.split(sep) if part.strip()]


def load_config():
    codex_home = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
    auth_json = read_json(codex_home / "auth.json")
    config_toml = read_text(codex_home / "config.toml")

    api_key = os.environ.get("OPENAI_API_KEY") or auth_json.get("OPENAI_API_KEY")
    base_url = (
        os.environ.get("OPENAI_BASE_URL")
        or find_toml_string(config_toml, "base_url")
        or DEFAULT_BASE_URL
    )
    model = (
        os.environ.get("IMAGE_MODEL")
        or os.environ.get("OPENAI_MODEL")
        or find_toml_string(config_toml, "model")
        or DEFAULT_MODEL
    )
    prompt = os.environ.get("IMAGE_PROMPT", "").strip()
    input_paths = split_paths(os.environ.get("IMAGE_INPUTS", ""))
    input_file_ids = [v.strip() for v in os.environ.get("IMAGE_FILE_IDS", "").split(",") if v.strip()]
    input_data_urls = [v.strip() for v in os.environ.get("IMAGE_DATA_URLS", "").split(",") if v.strip()]
    mask_path = Path(os.environ["IMAGE_MASK"]).expanduser() if os.environ.get("IMAGE_MASK") else None
    has_inputs = bool(input_paths or input_file_ids or input_data_urls)
    action = os.environ.get("IMAGE_ACTION") or ("edit" if has_inputs else "generate")
    output_format = os.environ.get("IMAGE_FORMAT", "png").lower()
    output_path = Path(os.environ.get("IMAGE_OUTPUT", DEFAULT_OUTPUT_PATH))

    if not api_key:
        raise SystemExit("OPENAI_API_KEY not found in environment or Codex auth.json")
    if not prompt:
        raise SystemExit("IMAGE_PROMPT is required")
    if action == "edit" and not has_inputs:
        raise SystemExit("IMAGE_ACTION=edit requires IMAGE_INPUTS, IMAGE_FILE_IDS, or IMAGE_DATA_URLS")
    if mask_path and not has_inputs:
        raise SystemExit("IMAGE_MASK requires an input image; the mask applies to the first image")
    if model.startswith("gpt-image-"):
        raise SystemExit("Responses API model must be a text-capable model, not gpt-image-*")

    return {
        "api_key": api_key,
        "base_url": base_url.rstrip("/"),
        "model": model,
        "prompt": prompt,
        "input_paths": input_paths,
        "input_file_ids": input_file_ids,
        "input_data_urls": input_data_urls,
        "mask_path": mask_path,
        "action": action,
        "output_path": output_path,
        "output_format": output_format,
        "size": os.environ.get("IMAGE_SIZE"),
        "quality": os.environ.get("IMAGE_QUALITY"),
        "compression": os.environ.get("IMAGE_COMPRESSION"),
        "background": os.environ.get("IMAGE_BACKGROUND"),
    }


def open_api_request(config, endpoint, payload):
    request = urllib.request.Request(
        f"{config['base_url']}/{endpoint.lstrip('/')}",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {config['api_key']}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        return urllib.request.urlopen(request, timeout=300)
    except urllib.error.HTTPError as error:
        body = error.read().decode("utf-8", errors="replace")
        raise SystemExit(f"HTTP {error.code}: {body}")


def multipart_body(fields, files):
    boundary = f"----codex-{uuid.uuid4().hex}"
    chunks = []
    for name, value in fields.items():
        chunks.extend([
            f"--{boundary}\r\n".encode(),
            f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode(),
            str(value).encode(),
            b"\r\n",
        ])
    for name, path in files.items():
        data = path.read_bytes()
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        chunks.extend([
            f"--{boundary}\r\n".encode(),
            f'Content-Disposition: form-data; name="{name}"; filename="{path.name}"\r\n'.encode(),
            f"Content-Type: {content_type}\r\n\r\n".encode(),
            data,
            b"\r\n",
        ])
    chunks.append(f"--{boundary}--\r\n".encode())
    return boundary, b"".join(chunks)


def upload_file(config, path):
    if not path.exists():
        raise SystemExit(f"Input file not found: {path}")
    if path.stat().st_size >= 50 * 1024 * 1024:
        raise SystemExit(f"Input file must be under 50MB: {path}")
    boundary, body = multipart_body({"purpose": "vision"}, {"file": path})
    request = urllib.request.Request(
        f"{config['base_url']}/files",
        data=body,
        headers={
            "Authorization": f"Bearer {config['api_key']}",
            "Content-Type": f"multipart/form-data; boundary={boundary}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=300) as response:
            result = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        body = error.read().decode("utf-8", errors="replace")
        raise SystemExit(f"File upload HTTP {error.code}: {body}")
    return result["id"]


def file_to_data_url(path):
    if not path.exists():
        raise SystemExit(f"Input file not found: {path}")
    if path.stat().st_size >= 50 * 1024 * 1024:
        raise SystemExit(f"Input file must be under 50MB: {path}")
    content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{content_type};base64,{encoded}"


def collect_images(value, images):
    if isinstance(value, dict):
        if value.get("type") == "image_generation_call" and value.get("result"):
            images.append(value["result"])
        if value.get("b64_json"):
            images.append(value["b64_json"])
        for nested in value.values():
            collect_images(nested, images)
    elif isinstance(value, list):
        for nested in value:
            collect_images(nested, images)


def parse_sse_images(response):
    images = []
    data_lines = []

    for raw_line in response:
        line = raw_line.decode("utf-8", errors="replace").rstrip("\n")
        if not line.strip():
            if not data_lines:
                continue
            payload = "\n".join(data_lines)
            data_lines = []
            if payload.strip() == "[DONE]":
                continue
            event = json.loads(payload)
            collect_images(event, images)
            continue
        if line.startswith("data:"):
            data_lines.append(line[5:].strip())

    if data_lines:
        payload = "\n".join(data_lines)
        if payload.strip() != "[DONE]":
            collect_images(json.loads(payload), images)

    return images


def build_payload(config, uploaded_file_ids, mask_file_id):
    content = [{"type": "input_text", "text": config["prompt"]}]
    for data_url in config["input_data_urls"]:
        content.append({"type": "input_image", "image_url": data_url})
    input_file_ids = config["input_file_ids"] + uploaded_file_ids
    for file_id in input_file_ids:
        content.append({"type": "input_image", "file_id": file_id})

    tool = {
        "type": "image_generation",
        "action": config["action"],
        "output_format": config["output_format"],
    }
    for env_key, tool_key in [
        ("size", "size"),
        ("quality", "quality"),
        ("background", "background"),
    ]:
        if config[env_key]:
            tool[tool_key] = config[env_key]
    if config["compression"]:
        tool["output_compression"] = int(config["compression"])
    if mask_file_id:
        tool["input_image_mask"] = {"file_id": mask_file_id}

    return {
        "model": config["model"],
        "instructions": (
            "You are an image generation assistant. Use the image_generation tool "
            "to create or edit exactly one image that matches the user request."
        ),
        "input": [{"role": "user", "content": content}],
        "tools": [tool],
        "tool_choice": {"type": "image_generation"},
        "store": False,
        "stream": True,
    }


def expected_signature(output_format):
    return {
        "png": b"\x89PNG\r\n\x1a\n",
        "jpeg": b"\xff\xd8\xff",
        "jpg": b"\xff\xd8\xff",
        "webp": b"RIFF",
    }.get(output_format)


def main():
    config = load_config()
    if config["mask_path"]:
        uploaded_file_ids = [upload_file(config, path) for path in config["input_paths"]]
        mask_file_id = upload_file(config, config["mask_path"])
    else:
        config["input_data_urls"].extend(file_to_data_url(path) for path in config["input_paths"])
        uploaded_file_ids = []
        mask_file_id = None
    payload = build_payload(config, uploaded_file_ids, mask_file_id)
    with open_api_request(config, "/responses", payload) as response:
        images = parse_sse_images(response)
    if not images:
        raise SystemExit("No image_generation_call result found in response")

    image_bytes = base64.b64decode(images[-1])
    signature = expected_signature(config["output_format"])
    if signature and not image_bytes.startswith(signature):
        raise SystemExit(f"Output does not look like {config['output_format']}")

    output_path = config["output_path"]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(image_bytes)
    print(f"Saved: {output_path}")


if __name__ == "__main__":
    main()
